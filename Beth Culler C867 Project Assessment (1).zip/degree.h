#ifndef DEGREE_H
#define DEGREE_H
#include<string>
using namespace std;

	enum Degree { SECURITY, NETWORKING, SOFTWARE };

	static const string degreeTypeStrings[] = { "SECURITY", "NETWORKING", "SOFTWARE" };

#endif 
